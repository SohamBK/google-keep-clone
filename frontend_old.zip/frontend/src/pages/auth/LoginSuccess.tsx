// import React, { useEffect } from "react";
// import { useDispatch } from "react-redux";
// import { useNavigate } from "react-router-dom";
// import { setAuthTokens } from "../../store/auth/authSlice";

// interface DecodedToken {
//   id: string;
//   email?: string;
//   exp?: number;
// }

// const LoginSuccess: React.FC = () => {
//   const dispatch = useDispatch();
//   const navigate = useNavigate();

//   useEffect(() => {
//     const urlParams = new URLSearchParams(window.location.search);
//     const token = urlParams.get("token");

//     if (token) {
//       // Decode the token payload to extract user info
//       const decoded = jwtDecode<DecodedToken>(token);
//       const user = {
//         userId: decoded.id,
//         email: decoded.email || "",
//       };

//       dispatch(setAuthTokens({ user, accessToken: token }));
//       navigate("/"); // redirect to dashboard/home after login
//     } else {
//       navigate("/login");
//     }
//   }, [dispatch, navigate]);

//   return <p>Logging you in via Google...</p>;
// };

// export default LoginSuccess;
